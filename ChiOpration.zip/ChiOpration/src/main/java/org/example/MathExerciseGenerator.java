package org.example;

import java.io.*;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class MathExerciseGenerator {

    // 题目数量
    private int numExercises;
    // 最大值
    private int max;
    // 运算符
    private List<Character> operators;
    // 是否含有小数
    private boolean hasDecimal;
    // 是否含有括号
    private boolean hasBrackets;

    // 构造函数
    public MathExerciseGenerator(int numExercises, int max, List<Character> operators, boolean hasDecimal, boolean hasBrackets) {
        this.numExercises = numExercises;
        this.max = max;
        this.operators = operators;
        this.hasDecimal = hasDecimal;
        this.hasBrackets = hasBrackets;
    }

    // 生成随机数
    private Number getRandomNumber() {
        Random random = new Random();
        if (hasDecimal) {
            String format = String.format("%.2f", random.nextDouble() * max);
            return Double.valueOf(format);
        } else {
            return random.nextInt(max);
        }
    }

    // 获取运算符
    private char getOperator() {
        int index = new Random().nextInt(operators.size());
        return operators.get(index);
    }

    // 随机生成表达式
    private String generateExpression() {
        StringBuilder expression = new StringBuilder();
        int numOperands = new Random().nextInt(5) + 2; // 2-4个操作数
        List<Number> operands = new ArrayList<>();
        for (int i = 0; i < numOperands; i++) {
            operands.add(getRandomNumber());
        }
        int preLeftBrackets = 0;
        for (int i = 0; i < numOperands - 1; i++) {
            int preIndex = expression.length();
            expression.append(operands.get(i)).append(" ");
            int nextIndex = expression.length();
            expression.append(getOperator()).append(" ");
            if (hasBrackets) {
                boolean isPre = false;
                if (new Random().nextBoolean()) {
                    expression.insert(preIndex, "(");
                    preLeftBrackets++;
                    isPre = true;
                }
                if (preLeftBrackets > 0 && !isPre && new Random().nextBoolean()) {
                    expression.insert(nextIndex, ")");
                    preLeftBrackets--;
                }
            }
        }
        expression.append(operands.get(numOperands - 1));
        while (preLeftBrackets-- > 0) {
            expression.append(")");
        }
        return expression.toString();
    }

    // 生成练习题
    public List<String> generateExercises() {
        List<String> exercises = new ArrayList<>();
        for (int i = 0; i < numExercises; i++) {
            exercises.add(generateExpression() + " =");
        }
        return exercises;
    }

    // 输出到文件
    public void outputToFile(String filePath, String[] title, String format) throws IOException {
        format += ".txt";
        File file = new File(filePath, format);
        if (!file.getParentFile().exists()) {
            boolean mkdirs = file.getParentFile().mkdirs();
            if (!mkdirs) {
                throw new EOFException("创建文件失败");
            }
        }

        FileWriter fw = new FileWriter(file);
        PrintWriter pw = new PrintWriter(fw);
        List<String> exercises = generateExercises();
        for (String s : title) {
            pw.println(s);
        }
        for (String exercise : exercises) {
            pw.println(exercise);
        }
        pw.close();
        fw.close();
    }

    // 打印到控制台
    public void printToConsole() {
        List<String> exercises = generateExercises();
        for (String exercise : exercises) {
            System.out.println(exercise);
        }
    }

    // 显示选择界面
    public static void showDialog() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("**********驰哥运算自动生成程序**********");
        System.out.print("请输入练习题数量：");
        int numExercises = scanner.nextInt();
        System.out.print("请输入最大数：");
        int max = scanner.nextInt();
        System.out.print("请选择运算符（+、-、*、/）：");
        String operatorStr = scanner.next();
        List<Character> operators = new ArrayList<>();
        for (int i = 0; i < operatorStr.length(); i++) {
            operators.add(operatorStr.charAt(i));
        }
        System.out.print("是否含有小数（是/否）：");
        String decimals = scanner.next();

        boolean hasDecimal = decimals.equals("是");
        System.out.print("是否含有括号（是/否）：");

        String isBrackets = scanner.next();
        boolean hasBrackets = isBrackets.equals("是");
        System.out.println("请选择输出方式：1. 输出到控制台 2. 输出到文件");
        int choice = scanner.nextInt();
        LocalDateTime now = LocalDateTime.now();
        MathExerciseGenerator generator = new MathExerciseGenerator(numExercises, max, operators, hasDecimal, hasBrackets);
        if (choice == 1) {
            generator.printToConsole();
        } else {
            try {
                String title[] = {"练习题数目" + numExercises, "最大数" + max, "选择的运算符" + operatorStr, "是否含有小数" + decimals,
                        "是否含有括号" + isBrackets};
                String format = now.format(DateTimeFormatter.ofPattern("yyyy/MM/dd/")) + UUID.randomUUID();
                String filePath = "F:\\OfficeProduct\\javaIdeaProjects\\ChiOpration\\Operators";
                generator.outputToFile(filePath, title, format);
                System.out.println("成功生成练习题文件！");
            } catch (IOException e) {
                System.out.println("生成练习题文件失败！");
                e.printStackTrace();
            }
        }
        scanner.close();
    }

    public static void main(String[] args) {
        showDialog();
    }
}